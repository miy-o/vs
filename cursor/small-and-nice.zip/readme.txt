﻿=== Win 7 Reloaded Cursor Set ===

By: Jackall4BDN

Download: http://www.rw-designer.com/cursor-set/small-and-nice

Author's decription:

Small set of freshed up Win7 cursors

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.